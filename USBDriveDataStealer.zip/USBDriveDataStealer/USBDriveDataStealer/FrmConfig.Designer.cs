﻿
namespace USBDriveDataStealer
{
    partial class FrmConfig
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmConfig));
            this.GrpDataToSteal = new System.Windows.Forms.GroupBox();
            this.NUDsize = new System.Windows.Forms.NumericUpDown();
            this.RBextensions = new System.Windows.Forms.RadioButton();
            this.BTNremoveExtension = new System.Windows.Forms.Button();
            this.TXTextension = new System.Windows.Forms.TextBox();
            this.BTNaddExtension = new System.Windows.Forms.Button();
            this.RBmaxSize = new System.Windows.Forms.RadioButton();
            this.RBall = new System.Windows.Forms.RadioButton();
            this.LBextensions = new System.Windows.Forms.ListBox();
            this.TXTpath = new System.Windows.Forms.TextBox();
            this.BTNpath = new System.Windows.Forms.Button();
            this.GRPfileSavingPath = new System.Windows.Forms.GroupBox();
            this.BTNwait = new System.Windows.Forms.Button();
            this.BTNstop = new System.Windows.Forms.Button();
            this.TMRwaitForDrive = new System.Windows.Forms.Timer(this.components);
            this.PBcopying = new System.Windows.Forms.ProgressBar();
            this.GrpDataToSteal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUDsize)).BeginInit();
            this.GRPfileSavingPath.SuspendLayout();
            this.SuspendLayout();
            // 
            // GrpDataToSteal
            // 
            this.GrpDataToSteal.Controls.Add(this.NUDsize);
            this.GrpDataToSteal.Controls.Add(this.RBextensions);
            this.GrpDataToSteal.Controls.Add(this.BTNremoveExtension);
            this.GrpDataToSteal.Controls.Add(this.TXTextension);
            this.GrpDataToSteal.Controls.Add(this.BTNaddExtension);
            this.GrpDataToSteal.Controls.Add(this.RBmaxSize);
            this.GrpDataToSteal.Controls.Add(this.RBall);
            this.GrpDataToSteal.Controls.Add(this.LBextensions);
            this.GrpDataToSteal.Location = new System.Drawing.Point(12, 12);
            this.GrpDataToSteal.Name = "GrpDataToSteal";
            this.GrpDataToSteal.Size = new System.Drawing.Size(464, 245);
            this.GrpDataToSteal.TabIndex = 0;
            this.GrpDataToSteal.TabStop = false;
            this.GrpDataToSteal.Text = "What do you want to steal?";
            // 
            // NUDsize
            // 
            this.NUDsize.Enabled = false;
            this.NUDsize.Location = new System.Drawing.Point(372, 48);
            this.NUDsize.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.NUDsize.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NUDsize.Name = "NUDsize";
            this.NUDsize.Size = new System.Drawing.Size(86, 22);
            this.NUDsize.TabIndex = 3;
            this.NUDsize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NUDsize.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // RBextensions
            // 
            this.RBextensions.AutoSize = true;
            this.RBextensions.Location = new System.Drawing.Point(6, 75);
            this.RBextensions.Name = "RBextensions";
            this.RBextensions.Size = new System.Drawing.Size(237, 21);
            this.RBextensions.TabIndex = 2;
            this.RBextensions.Text = "Only files with specific extensions";
            this.RBextensions.UseVisualStyleBackColor = true;
            this.RBextensions.CheckedChanged += new System.EventHandler(this.RBextensions_CheckedChanged_1);
            // 
            // BTNremoveExtension
            // 
            this.BTNremoveExtension.Enabled = false;
            this.BTNremoveExtension.Location = new System.Drawing.Point(237, 204);
            this.BTNremoveExtension.Name = "BTNremoveExtension";
            this.BTNremoveExtension.Size = new System.Drawing.Size(221, 33);
            this.BTNremoveExtension.TabIndex = 3;
            this.BTNremoveExtension.Text = "Remove";
            this.BTNremoveExtension.UseVisualStyleBackColor = true;
            this.BTNremoveExtension.Click += new System.EventHandler(this.BTNremoveExtension_Click);
            // 
            // TXTextension
            // 
            this.TXTextension.Enabled = false;
            this.TXTextension.Location = new System.Drawing.Point(6, 176);
            this.TXTextension.MaxLength = 5;
            this.TXTextension.Name = "TXTextension";
            this.TXTextension.Size = new System.Drawing.Size(452, 22);
            this.TXTextension.TabIndex = 4;
            this.TXTextension.Text = "MP3";
            this.TXTextension.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BTNaddExtension
            // 
            this.BTNaddExtension.Enabled = false;
            this.BTNaddExtension.Location = new System.Drawing.Point(6, 204);
            this.BTNaddExtension.Name = "BTNaddExtension";
            this.BTNaddExtension.Size = new System.Drawing.Size(221, 33);
            this.BTNaddExtension.TabIndex = 2;
            this.BTNaddExtension.Text = "Add";
            this.BTNaddExtension.UseVisualStyleBackColor = true;
            this.BTNaddExtension.Click += new System.EventHandler(this.BTNaddExtension_Click);
            // 
            // RBmaxSize
            // 
            this.RBmaxSize.AutoSize = true;
            this.RBmaxSize.Location = new System.Drawing.Point(6, 48);
            this.RBmaxSize.Name = "RBmaxSize";
            this.RBmaxSize.Size = new System.Drawing.Size(360, 21);
            this.RBmaxSize.TabIndex = 1;
            this.RBmaxSize.Text = "All files smaller or equal than a specified size (in MB)";
            this.RBmaxSize.UseVisualStyleBackColor = true;
            this.RBmaxSize.CheckedChanged += new System.EventHandler(this.RBmaxSize_CheckedChanged);
            // 
            // RBall
            // 
            this.RBall.AutoSize = true;
            this.RBall.Location = new System.Drawing.Point(6, 21);
            this.RBall.Name = "RBall";
            this.RBall.Size = new System.Drawing.Size(118, 21);
            this.RBall.TabIndex = 0;
            this.RBall.Text = "All device files";
            this.RBall.UseVisualStyleBackColor = true;
            this.RBall.CheckedChanged += new System.EventHandler(this.RBall_CheckedChanged);
            // 
            // LBextensions
            // 
            this.LBextensions.Enabled = false;
            this.LBextensions.FormattingEnabled = true;
            this.LBextensions.ItemHeight = 16;
            this.LBextensions.Items.AddRange(new object[] {
            "BMP",
            "DOCX",
            "HTML",
            "JPG",
            "PDF",
            "TXT"});
            this.LBextensions.Location = new System.Drawing.Point(6, 102);
            this.LBextensions.MultiColumn = true;
            this.LBextensions.Name = "LBextensions";
            this.LBextensions.Size = new System.Drawing.Size(452, 68);
            this.LBextensions.Sorted = true;
            this.LBextensions.TabIndex = 1;
            // 
            // TXTpath
            // 
            this.TXTpath.Location = new System.Drawing.Point(6, 21);
            this.TXTpath.Name = "TXTpath";
            this.TXTpath.ReadOnly = true;
            this.TXTpath.Size = new System.Drawing.Size(452, 22);
            this.TXTpath.TabIndex = 6;
            this.TXTpath.Text = "%UserProfile%\\Documents\\";
            // 
            // BTNpath
            // 
            this.BTNpath.Location = new System.Drawing.Point(6, 49);
            this.BTNpath.Name = "BTNpath";
            this.BTNpath.Size = new System.Drawing.Size(452, 33);
            this.BTNpath.TabIndex = 5;
            this.BTNpath.Text = "Change path";
            this.BTNpath.UseVisualStyleBackColor = true;
            this.BTNpath.Click += new System.EventHandler(this.BTNpath_Click);
            // 
            // GRPfileSavingPath
            // 
            this.GRPfileSavingPath.Controls.Add(this.TXTpath);
            this.GRPfileSavingPath.Controls.Add(this.BTNpath);
            this.GRPfileSavingPath.Location = new System.Drawing.Point(12, 263);
            this.GRPfileSavingPath.Name = "GRPfileSavingPath";
            this.GRPfileSavingPath.Size = new System.Drawing.Size(464, 89);
            this.GRPfileSavingPath.TabIndex = 7;
            this.GRPfileSavingPath.TabStop = false;
            this.GRPfileSavingPath.Text = "Where do you want to save the stolen files?";
            // 
            // BTNwait
            // 
            this.BTNwait.Location = new System.Drawing.Point(12, 358);
            this.BTNwait.Name = "BTNwait";
            this.BTNwait.Size = new System.Drawing.Size(221, 33);
            this.BTNwait.TabIndex = 5;
            this.BTNwait.Text = "Wait for USB Drive connection";
            this.BTNwait.UseVisualStyleBackColor = true;
            this.BTNwait.Click += new System.EventHandler(this.BTNwait_Click);
            // 
            // BTNstop
            // 
            this.BTNstop.Enabled = false;
            this.BTNstop.Location = new System.Drawing.Point(239, 358);
            this.BTNstop.Name = "BTNstop";
            this.BTNstop.Size = new System.Drawing.Size(237, 33);
            this.BTNstop.TabIndex = 8;
            this.BTNstop.Text = "Stop to wait";
            this.BTNstop.UseVisualStyleBackColor = true;
            this.BTNstop.Click += new System.EventHandler(this.BTNstop_Click);
            // 
            // TMRwaitForDrive
            // 
            this.TMRwaitForDrive.Interval = 5000;
            this.TMRwaitForDrive.Tick += new System.EventHandler(this.TMRwaitForDrive_Tick);
            // 
            // PBcopying
            // 
            this.PBcopying.Location = new System.Drawing.Point(12, 397);
            this.PBcopying.MarqueeAnimationSpeed = 15;
            this.PBcopying.Name = "PBcopying";
            this.PBcopying.Size = new System.Drawing.Size(464, 19);
            this.PBcopying.TabIndex = 9;
            // 
            // FrmConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 426);
            this.Controls.Add(this.PBcopying);
            this.Controls.Add(this.BTNstop);
            this.Controls.Add(this.BTNwait);
            this.Controls.Add(this.GRPfileSavingPath);
            this.Controls.Add(this.GrpDataToSteal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmConfig";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "USB Drive Data Stealer";
            this.Load += new System.EventHandler(this.FrmConfig_Load);
            this.GrpDataToSteal.ResumeLayout(false);
            this.GrpDataToSteal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUDsize)).EndInit();
            this.GRPfileSavingPath.ResumeLayout(false);
            this.GRPfileSavingPath.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrpDataToSteal;
        private System.Windows.Forms.RadioButton RBmaxSize;
        private System.Windows.Forms.RadioButton RBall;
        private System.Windows.Forms.RadioButton RBextensions;
        private System.Windows.Forms.NumericUpDown NUDsize;
        private System.Windows.Forms.ListBox LBextensions;
        private System.Windows.Forms.Button BTNaddExtension;
        private System.Windows.Forms.Button BTNremoveExtension;
        private System.Windows.Forms.TextBox TXTextension;
        private System.Windows.Forms.TextBox TXTpath;
        private System.Windows.Forms.Button BTNpath;
        private System.Windows.Forms.GroupBox GRPfileSavingPath;
        private System.Windows.Forms.Button BTNwait;
        private System.Windows.Forms.Button BTNstop;
        private System.Windows.Forms.Timer TMRwaitForDrive;
        private System.Windows.Forms.ProgressBar PBcopying;
    }
}

